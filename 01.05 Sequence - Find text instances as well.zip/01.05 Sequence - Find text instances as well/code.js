"use strict";
// This plugin displays IDs of selected components in the order they were selected
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).
// This shows the HTML page in "ui.html".
figma.showUI(__html__, { width: 300, height: 400 });
// Array to keep track of selection order
let selectionOrder = [];
// Listen for any changes in what the user has selected in Figma
figma.on("selectionchange", () => {
    const currentSelection = figma.currentPage.selection;
    // Determine newly selected nodes
    const added = currentSelection.filter(node => !selectionOrder.includes(node));
    // Determine deselected nodes
    const removed = selectionOrder.filter(node => !currentSelection.includes(node));
    // Remove deselected nodes from the selectionOrder
    selectionOrder = selectionOrder.filter(node => !removed.includes(node));
    // Add newly selected nodes to the end of the selectionOrder
    selectionOrder.push(...added);
    // Initialize an array to keep track of all selected text nodes
    const allTextNodes = [];
    selectionOrder.forEach(node => {
        if (node.type === 'GROUP' || node.type === 'FRAME' || node.type === 'INSTANCE') {
            const textChildren = node.findAll(child => child.type === 'TEXT');
            textChildren.forEach(textNode => {
                allTextNodes.push({
                    parentId: node.id,
                    textId: textNode.id,
                    textName: textNode.name
                });
            });
        }
        else if (node.type === 'TEXT') {
            // If the node itself is a TEXT node, add it directly
            allTextNodes.push({
                parentId: node.parent ? node.parent.id : 'No Parent',
                textId: node.id,
                textName: node.name
            });
        }
    });
    // Create the ordered list based on selectionOrder
    const selectedIds = selectionOrder.map((node, index) => ({
        index: index + 1, // Selection order (1-based)
        id: node.id, // Unique Figma node ID
        name: node.name, // Name of the node in Figma
        type: node.type // Type of node (e.g., FRAME, COMPONENT, etc.)
    }));
    // Send the ordered selection data and all text nodes to the UI
    figma.ui.postMessage({
        type: 'selection-updated',
        selection: selectedIds,
        textNodes: allTextNodes
    });
});
// Listen for messages from the UI
figma.ui.onmessage = (msg) => {
    if (msg.type === 'close') {
        figma.closePlugin();
    }
    // Handle relabeling of text nodes
    if (msg.type === 'relabel-text-nodes') {
        // Helper function to load all fonts actually used in each text node
        function loadAllFontsForTextNode(textNode) {
            return __awaiter(this, void 0, void 0, function* () {
                const len = textNode.characters.length;
                const fontPromises = [];
                for (let i = 0; i < len; i++) {
                    const fontName = textNode.getRangeFontName(i, i + 1);
                    // If the font is not "mixed", load it
                    if (fontName !== figma.mixed) {
                        fontPromises.push(figma.loadFontAsync(fontName));
                    }
                }
                // Wait for all fonts in the node to be loaded
                yield Promise.all(fontPromises);
            });
        }
        // Reconstruct the list of text nodes to relabel
        const relabelTextNodes = [];
        selectionOrder.forEach(node => {
            if (node.type === 'GROUP' || node.type === 'FRAME' || node.type === 'INSTANCE') {
                const textChildren = node.findAll(child => child.type === 'TEXT');
                textChildren.forEach(textNode => relabelTextNodes.push(textNode));
            }
            else if (node.type === 'TEXT') {
                relabelTextNodes.push(node);
            }
        });
        // Initialize a global counter for numbering
        let counter = 1;
        // For each text node, load its fonts, then update the text
        (() => __awaiter(void 0, void 0, void 0, function* () {
            for (const textNode of relabelTextNodes) {
                yield loadAllFontsForTextNode(textNode);
                // Update the characters while preserving styling
                textNode.characters = `${counter}`;
                counter++;
            }
            // Optionally, inform the UI that relabeling is done
            figma.ui.postMessage({ type: 'relabel-complete' });
        }))().catch(error => {
            console.error("Error loading fonts:", error);
            figma.notify("Failed to load required fonts for relabeling.");
        });
    }
};
